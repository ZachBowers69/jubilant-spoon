# GeoShorts Studio for iPhone

SwiftUI starter app for planning automated geography YouTube Shorts. It supports manual JSON pasted from ChatGPT, satellite map previews, structured geographic scenes, camera instructions, overlays, and narration audio generation.

## TTS choices

### 1. On-device Apple voice — permanently free
The app uses `AVSpeechSynthesizer.write(_:toBufferCallback:)` to create a shareable CAF narration file entirely on the iPhone. No server, API key, account, or quota is needed. In the editor, tap **Generate audio**, then **Share narration file**.

### 2. Cloudflare Aura — website/serverless option
The `cloudflare-tts` folder contains a protected Cloudflare Worker. It calls Cloudflare Workers AI Aura and returns MP3 audio. Cloudflare currently offers a free AI allocation, but Aura has usage pricing, so this should be treated as free within the current allocation—not unlimited forever.

Deploy from an iPhone:
1. Create a free Cloudflare account.
2. Put this repository on GitHub.
3. In Cloudflare Dashboard, open **Workers & Pages**, create/import a Worker from the repository, and use `cloudflare-tts` as the root directory.
4. Add an AI binding named `AI` if Cloudflare did not read it from `wrangler.toml`.
5. Add an encrypted secret named `APP_TOKEN` with a long random value.
6. Deploy and copy the resulting `https://...workers.dev` URL.
7. In the app Settings, select **Cloudflare Aura**, paste the Worker URL and the same app token.

Never put a Cloudflare account API token in the iPhone app. The Worker uses its server-side AI binding.

## Build an unsigned IPA entirely from an iPhone

The included GitHub Actions workflow compiles the app on a hosted Mac and gives you an unsigned IPA. ESign still needs a usable signing certificate/profile to sign and install it; compiling an IPA does not bypass Apple's signing requirements.

1. On your iPhone, create/sign in to a GitHub account.
2. Create a repository. Public repositories receive free standard Actions usage; private repositories have a limited monthly allowance.
3. Upload all files from this project ZIP to the repository, keeping `.github/workflows/build-unsigned-ipa.yml` intact. The easiest iPhone method is GitHub's web upload in Safari, or a Git client such as Working Copy.
4. Open the repository's **Actions** tab.
5. Select **Build unsigned IPA** → **Run workflow**.
6. Open the completed workflow run and download the `GeoShortsStudio-unsigned-ipa` artifact.
7. In the Files app, unzip the downloaded artifact ZIP. Inside is `GeoShortsStudio-unsigned.ipa`.
8. Import that IPA into ESign, choose your certificate and provisioning profile, sign it, then install.

### Important signing reality
GitHub can compile the app for free, but ESign cannot install an unsigned app by itself. You still need a certificate/profile that permits your device and bundle identifier. Free certificates are commonly short-lived; paid Apple Developer membership or another legitimate signing arrangement offers more reliable provisioning. Revoked or untrusted shared certificates may stop working without warning.

## Current scope

Included:
- Manual ChatGPT script import
- Structured scenes and map instructions
- Satellite preview
- Camera metadata
- Multiple/combined border instructions
- Routes, expansion, arrows, graphic and SFX cues
- On-device voice preview
- Exportable on-device narration audio
- Optional Cloudflare Aura MP3 generation
- iPhone-triggered GitHub Actions IPA build

Not yet included:
- Complete frame-by-frame animated border renderer
- Automatic GeoJSON lookup/union
- Boat and route animation rendering
- Final caption timing/alignment
- One-tap finished 1080×1920 MP4 export
