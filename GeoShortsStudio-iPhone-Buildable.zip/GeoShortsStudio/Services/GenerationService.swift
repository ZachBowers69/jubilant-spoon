import Foundation

protocol TextGenerationClient {
    func generate(prompt: String) async throws -> String
}

struct OpenAIClient: TextGenerationClient {
    let apiKey: String

    func generate(prompt: String) async throws -> String {
        guard !apiKey.isEmpty else { throw AppError.message("Add an OpenAI API key in Settings.") }
        var request = URLRequest(url: URL(string: "https://api.openai.com/v1/responses")!)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "model": "gpt-5-mini",
            "input": prompt
        ])
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw AppError.message(String(data: data, encoding: .utf8) ?? "OpenAI request failed")
        }
        let payload = try JSONDecoder().decode(OpenAIResponse.self, from: data)
        return payload.output.compactMap(\.content).flatMap { $0 }.compactMap(\.text).joined()
    }
}

private struct OpenAIResponse: Decodable {
    struct Output: Decodable { let content: [Content]? }
    struct Content: Decodable { let text: String? }
    let output: [Output]
}

struct OllamaClient: TextGenerationClient {
    let baseURL: String
    let model: String

    func generate(prompt: String) async throws -> String {
        guard let url = URL(string: baseURL.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/api/generate") else {
            throw AppError.message("Invalid Ollama URL")
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = 180
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "model": model,
            "prompt": prompt,
            "stream": false,
            "format": "json"
        ])
        let (data, _) = try await URLSession.shared.data(for: request)
        let payload = try JSONDecoder().decode(OllamaResponse.self, from: data)
        return payload.response
    }
}

private struct OllamaResponse: Decodable { let response: String }

enum AppError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let value) = self { return value }; return nil }
}

enum JSONCleaner {
    static func data(from text: String) -> Data? {
        var cleaned = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if cleaned.hasPrefix("```") {
            cleaned = cleaned.replacingOccurrences(of: "```json", with: "")
            cleaned = cleaned.replacingOccurrences(of: "```", with: "")
        }
        return cleaned.data(using: .utf8)
    }
}
