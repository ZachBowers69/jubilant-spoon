import Foundation

enum PromptFactory {
    static let schemaInstructions = """
    Return strict JSON only. Create a vertical geography short with a strong hook and 35-55 seconds of narration. Every scene must include narration, duration, camera, overlays, graphics, and soundEffects. Use real place labels. Include all geographic levels needed to visually locate the subject, from continent/country down to region/city. Mark borders that should be merged with combineBorders=true. Use route or overseasExpansion overlays where appropriate. Avoid unsupported factual claims.
    """

    static func ideas(topic: String) -> String {
        """
        Generate 12 compelling geography YouTube Shorts ideas about: \(topic).
        Return a JSON array with title, hook, and angle.
        Ideas should be surprising, fact-checkable, visually map-driven, and varied.
        """
    }

    static func script(for idea: VideoIdea) -> String {
        """
        \(schemaInstructions)
        Idea title: \(idea.title)
        Hook: \(idea.hook)
        Angle: \(idea.angle)

        JSON shape:
        {"title":"","narration":"","scenes":[{"narration":"","duration":5,"camera":{"centerLatitude":0,"centerLongitude":0,"altitudeMeters":1000000,"headingDegrees":0,"pitchDegrees":0,"easing":"easeInOut"},"overlays":[{"kind":"country","labels":["France"],"geoJSONURL":null,"combineBorders":false,"fillOpacity":0.2,"lineWidth":4,"animation":"draw"}],"graphics":[],"soundEffects":[]}]}
        """
    }
}
