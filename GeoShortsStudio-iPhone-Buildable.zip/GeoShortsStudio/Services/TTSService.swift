import AVFoundation
import Foundation

struct TTSService {
    enum TTSError: LocalizedError {
        case invalidEndpoint
        case emptyAudio
        case server(String)

        var errorDescription: String? {
            switch self {
            case .invalidEndpoint: return "Enter a valid HTTPS TTS endpoint in Settings."
            case .emptyAudio: return "The TTS service returned no audio."
            case .server(let message): return message
            }
        }
    }

    static func generateOnDevice(text: String, settings: RenderSettings) async throws -> URL {
        let outputURL = FileManager.default.temporaryDirectory
            .appendingPathComponent("geoshorts-\(UUID().uuidString).caf")
        let synthesizer = AVSpeechSynthesizer()
        let utterance = AVSpeechUtterance(string: text)
        utterance.rate = settings.speakingRate
        utterance.preUtteranceDelay = 0.12
        utterance.postUtteranceDelay = 0.18
        if let id = settings.voiceIdentifier {
            utterance.voice = AVSpeechSynthesisVoice(identifier: id)
        }

        return try await withCheckedThrowingContinuation { continuation in
            var audioFile: AVAudioFile?
            var resumed = false
            synthesizer.write(utterance) { buffer in
                guard let pcm = buffer as? AVAudioPCMBuffer else { return }
                if pcm.frameLength == 0 {
                    if !resumed {
                        resumed = true
                        if audioFile == nil {
                            continuation.resume(throwing: TTSError.emptyAudio)
                        } else {
                            continuation.resume(returning: outputURL)
                        }
                    }
                    return
                }
                do {
                    if audioFile == nil {
                        audioFile = try AVAudioFile(forWriting: outputURL, settings: pcm.format.settings)
                    }
                    try audioFile?.write(from: pcm)
                } catch {
                    if !resumed {
                        resumed = true
                        continuation.resume(throwing: error)
                    }
                }
            }
        }
    }

    static func generateCloudflare(text: String, endpoint: String, appToken: String, speaker: String) async throws -> URL {
        guard let url = URL(string: endpoint), url.scheme == "https" else { throw TTSError.invalidEndpoint }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if !appToken.isEmpty { request.setValue("Bearer \(appToken)", forHTTPHeaderField: "Authorization") }
        request.httpBody = try JSONSerialization.data(withJSONObject: ["text": text, "speaker": speaker])

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw TTSError.emptyAudio }
        guard (200..<300).contains(http.statusCode) else {
            let message = String(data: data, encoding: .utf8) ?? "TTS failed with HTTP \(http.statusCode)."
            throw TTSError.server(message)
        }
        guard !data.isEmpty else { throw TTSError.emptyAudio }
        let outputURL = FileManager.default.temporaryDirectory
            .appendingPathComponent("geoshorts-\(UUID().uuidString).mp3")
        try data.write(to: outputURL, options: .atomic)
        return outputURL
    }
}
