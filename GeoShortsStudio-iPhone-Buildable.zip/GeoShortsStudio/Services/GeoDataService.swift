import Foundation
import MapKit

actor GeoDataService {
    static let shared = GeoDataService()

    // Production recommendation: proxy Natural Earth, OSM/Nominatim and Overpass
    // through your own cache service to obey rate limits and normalize geometry.
    func search(_ label: String) async throws -> MKMapItem {
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = label
        let response = try await MKLocalSearch(request: request).start()
        guard let item = response.mapItems.first else { throw AppError.message("Could not locate \(label)") }
        return item
    }
}
