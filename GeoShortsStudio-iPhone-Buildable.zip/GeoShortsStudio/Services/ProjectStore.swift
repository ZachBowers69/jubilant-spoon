import Foundation

@MainActor
final class ProjectStore: ObservableObject {
    @Published var ideas: [VideoIdea] = []
    @Published var projects: [GeoProject] = []
    @Published var selectedProjectID: UUID?
    @Published var provider: ScriptProvider = .manual
    @Published var apiKey = ""
    @Published var ollamaURL = "http://192.168.1.10:11434"
    @Published var ollamaModel = "llama3.1:8b"
    @Published var ttsProvider: TTSProvider = .onDevice
    @Published var ttsEndpoint = ""
    @Published var ttsAppToken = ""
    @Published var ttsSpeaker = "luna"
    @Published var isWorking = false
    @Published var errorMessage: String?

    private let fileURL: URL

    init() {
        let directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        fileURL = directory.appendingPathComponent("geoshorts-projects.json")
        load()
    }

    var selectedProject: GeoProject? {
        guard let id = selectedProjectID else { return nil }
        return projects.first(where: { $0.id == id })
    }

    func addProject(from script: GeneratedScript) {
        let project = GeoProject(name: script.title, script: script)
        projects.insert(project, at: 0)
        selectedProjectID = project.id
        save()
    }

    func replaceProject(_ project: GeoProject) {
        guard let index = projects.firstIndex(where: { $0.id == project.id }) else { return }
        projects[index] = project
        save()
    }

    func save() {
        do {
            let data = try JSONEncoder.pretty.encode(projects)
            try data.write(to: fileURL, options: .atomic)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func load() {
        guard let data = try? Data(contentsOf: fileURL),
              let decoded = try? JSONDecoder().decode([GeoProject].self, from: data) else { return }
        projects = decoded
    }
}

extension JSONEncoder {
    static var pretty: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        return encoder
    }
}
