import AVFoundation
import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var store: ProjectStore

    var body: some View {
        NavigationStack {
            Form {
                Section("Script generation") {
                    Picker("Provider", selection: $store.provider) {
                        ForEach(ScriptProvider.allCases) { Text($0.rawValue).tag($0) }
                    }
                    if store.provider == .openAI {
                        SecureField("OpenAI API key", text: $store.apiKey)
                    }
                    if store.provider == .ollama {
                        TextField("Ollama URL", text: $store.ollamaURL)
                            .textInputAutocapitalization(.never).keyboardType(.URL)
                        TextField("Model", text: $store.ollamaModel)
                    }
                }

                Section("Narration") {
                    Picker("TTS provider", selection: $store.ttsProvider) {
                        ForEach(TTSProvider.allCases) { Text($0.rawValue).tag($0) }
                    }
                    if store.ttsProvider == .cloudflare {
                        TextField("Worker HTTPS endpoint", text: $store.ttsEndpoint)
                            .textInputAutocapitalization(.never).keyboardType(.URL)
                        SecureField("App token", text: $store.ttsAppToken)
                        Picker("Voice", selection: $store.ttsSpeaker) {
                            ForEach(["luna", "athena", "asteria", "orion", "orpheus", "zeus", "hera", "stella"], id: \.self) {
                                Text($0.capitalized).tag($0)
                            }
                        }
                        Text("The token protects your Worker URL. Your Cloudflare API token stays only in Cloudflare.")
                            .font(.caption)
                    } else {
                        Text("Runs entirely on the iPhone and creates a shareable audio file without a backend.")
                            .font(.caption)
                    }
                }

                Section("Rendering status") {
                    Label("Satellite preview and camera scenes", systemImage: "checkmark.circle")
                    Label("Structured borders/routes/graphics", systemImage: "checkmark.circle")
                    Label("Exportable narration audio", systemImage: "checkmark.circle")
                    Label("Final MP4 compositor remains a later renderer phase", systemImage: "hammer")
                }
            }
            .navigationTitle("Settings")
        }
    }
}
