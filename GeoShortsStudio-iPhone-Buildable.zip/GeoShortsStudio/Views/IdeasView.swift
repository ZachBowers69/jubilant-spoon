import SwiftUI

struct IdeasView: View {
    @EnvironmentObject var store: ProjectStore
    @State private var topic = "surprising borders, enclaves, islands, and unusual geography"
    @State private var pastedJSON = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("Topic") {
                    TextField("Geography niche", text: $topic, axis: .vertical)
                    Button("Generate ideas") { Task { await generateIdeas() } }
                        .disabled(store.provider == .manual || store.isWorking)
                }

                if store.provider == .manual {
                    Section("ChatGPT workflow") {
                        Text("Copy the prompt below into your ChatGPT Project, then paste the returned JSON here. This keeps your Project context, but the transfer must remain manual because ChatGPT Projects are not an app API.")
                        ShareLink(item: PromptFactory.ideas(topic: topic)) { Label("Share prompt", systemImage: "square.and.arrow.up") }
                        TextEditor(text: $pastedJSON).frame(minHeight: 140)
                        Button("Import ideas") { importIdeas(pastedJSON) }
                    }
                }

                Section("Ideas") {
                    ForEach($store.ideas) { $idea in
                        VStack(alignment: .leading, spacing: 6) {
                            Toggle(idea.title, isOn: $idea.selected)
                            Text(idea.hook).font(.subheadline).foregroundStyle(.secondary)
                        }
                    }
                    if store.ideas.contains(where: \.selected) {
                        Button("Generate selected scripts") { Task { await generateSelected() } }
                    }
                }
            }
            .navigationTitle("GeoShorts Studio")
            .overlay { if store.isWorking { ProgressView().controlSize(.large) } }
            .alert("Error", isPresented: .constant(store.errorMessage != nil)) {
                Button("OK") { store.errorMessage = nil }
            } message: { Text(store.errorMessage ?? "") }
        }
    }

    private func client() -> TextGenerationClient {
        switch store.provider {
        case .openAI: return OpenAIClient(apiKey: store.apiKey)
        case .ollama: return OllamaClient(baseURL: store.ollamaURL, model: store.ollamaModel)
        case .manual: return OllamaClient(baseURL: "", model: "")
        }
    }

    private func generateIdeas() async {
        store.isWorking = true; defer { store.isWorking = false }
        do {
            let text = try await client().generate(prompt: PromptFactory.ideas(topic: topic))
            importIdeas(text)
        } catch { store.errorMessage = error.localizedDescription }
    }

    private func importIdeas(_ text: String) {
        do {
            guard let data = JSONCleaner.data(from: text) else { throw AppError.message("Could not read JSON") }
            store.ideas = try JSONDecoder().decode([VideoIdea].self, from: data)
        } catch { store.errorMessage = "Idea JSON error: \(error.localizedDescription)" }
    }

    private func generateSelected() async {
        for idea in store.ideas where idea.selected {
            if store.provider == .manual {
                pastedJSON = PromptFactory.script(for: idea)
                store.errorMessage = "The full-script prompt is ready in the text box. Share it to ChatGPT, then import the returned script from Projects."
                return
            }
            store.isWorking = true
            do {
                let text = try await client().generate(prompt: PromptFactory.script(for: idea))
                guard let data = JSONCleaner.data(from: text) else { throw AppError.message("Invalid JSON") }
                let script = try JSONDecoder().decode(GeneratedScript.self, from: data)
                store.addProject(from: script)
            } catch { store.errorMessage = error.localizedDescription }
            store.isWorking = false
        }
    }
}
