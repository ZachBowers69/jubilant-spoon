import SwiftUI

struct ProjectsView: View {
    @EnvironmentObject var store: ProjectStore
    @State private var importText = ""

    var body: some View {
        NavigationStack {
            List {
                Section("Import generated script") {
                    TextEditor(text: $importText).frame(minHeight: 100)
                    Button("Import script JSON") { importScript() }
                }
                Section("Projects") {
                    ForEach(store.projects) { project in
                        NavigationLink(project.name) { EditorView(projectID: project.id) }
                    }
                }
            }
            .navigationTitle("Projects")
        }
    }

    private func importScript() {
        do {
            guard let data = JSONCleaner.data(from: importText) else { throw AppError.message("Invalid text") }
            store.addProject(from: try JSONDecoder().decode(GeneratedScript.self, from: data))
            importText = ""
        } catch { store.errorMessage = error.localizedDescription }
    }
}
