import SwiftUI
import MapKit

struct EditorView: View {
    @EnvironmentObject var store: ProjectStore
    let projectID: UUID
    @StateObject private var speech = SpeechTimeline()
    @State private var sceneIndex = 0
    @State private var generatedAudioURL: URL?
    @State private var isGeneratingAudio = false
    @State private var audioError: String?

    private var project: GeoProject? { store.projects.first(where: { $0.id == projectID }) }

    var body: some View {
        Group {
            if let project, let script = project.script, !script.scenes.isEmpty {
                let scene = script.scenes[min(sceneIndex, script.scenes.count - 1)]
                VStack(spacing: 0) {
                    MapPreview(scene: scene).frame(maxHeight: .infinity)
                    VStack(alignment: .leading, spacing: 12) {
                        Text(scene.narration).font(.headline)
                        Slider(value: Binding(get: { Double(sceneIndex) }, set: { sceneIndex = Int($0.rounded()) }), in: 0...Double(max(0, script.scenes.count - 1)), step: 1)
                        HStack {
                            Button("Preview voice") { speech.speak(script.narration, settings: project.renderSettings) }
                            Button(isGeneratingAudio ? "Generating…" : "Generate audio") {
                                Task { await generateAudio(text: script.narration, settings: project.renderSettings) }
                            }
                            .disabled(isGeneratingAudio)
                            Spacer()
                            Text("Scene \(sceneIndex + 1)/\(script.scenes.count)")
                        }
                        if let generatedAudioURL {
                            ShareLink(item: generatedAudioURL) {
                                Label("Share narration file", systemImage: "square.and.arrow.up")
                            }
                        }
                        if let audioError {
                            Text(audioError).foregroundStyle(.red).font(.caption)
                        }
                        NavigationLink("Edit scene details") { SceneEditor(projectID: projectID, sceneIndex: sceneIndex) }
                    }.padding()
                }
                .navigationTitle(project.name)
                .navigationBarTitleDisplayMode(.inline)
            } else { ContentUnavailableView("No script", systemImage: "doc") }
        }
    }

    @MainActor
    private func generateAudio(text: String, settings: RenderSettings) async {
        isGeneratingAudio = true
        audioError = nil
        defer { isGeneratingAudio = false }
        do {
            switch store.ttsProvider {
            case .onDevice:
                generatedAudioURL = try await TTSService.generateOnDevice(text: text, settings: settings)
            case .cloudflare:
                generatedAudioURL = try await TTSService.generateCloudflare(
                    text: text,
                    endpoint: store.ttsEndpoint,
                    appToken: store.ttsAppToken,
                    speaker: store.ttsSpeaker
                )
            }
        } catch {
            audioError = error.localizedDescription
        }
    }
}

struct MapPreview: View {
    let scene: GeoScene
    var body: some View {
        Map(initialPosition: .camera(MapCamera(
            centerCoordinate: CLLocationCoordinate2D(latitude: scene.camera.centerLatitude, longitude: scene.camera.centerLongitude),
            distance: scene.camera.altitudeMeters,
            heading: scene.camera.headingDegrees,
            pitch: scene.camera.pitchDegrees
        ))) {
            Marker(scene.overlays.first?.labels.first ?? "Focus", coordinate: .init(latitude: scene.camera.centerLatitude, longitude: scene.camera.centerLongitude))
        }
        .mapStyle(.imagery(elevation: .realistic))
        .overlay(alignment: .topLeading) {
            VStack(alignment: .leading) {
                ForEach(scene.overlays) { overlay in
                    Text("\(overlay.kind.rawValue): \(overlay.labels.joined(separator: ", "))")
                }
            }
            .font(.caption.bold()).padding(8).background(.ultraThinMaterial).clipShape(RoundedRectangle(cornerRadius: 10)).padding()
        }
    }
}
