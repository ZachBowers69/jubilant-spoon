import SwiftUI

struct RootView: View {
    var body: some View {
        TabView {
            IdeasView().tabItem { Label("Ideas", systemImage: "lightbulb") }
            ProjectsView().tabItem { Label("Projects", systemImage: "film.stack") }
            SettingsView().tabItem { Label("Settings", systemImage: "gear") }
        }
    }
}
