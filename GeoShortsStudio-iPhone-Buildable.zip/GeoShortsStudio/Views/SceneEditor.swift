import SwiftUI

struct SceneEditor: View {
    @EnvironmentObject var store: ProjectStore
    let projectID: UUID
    let sceneIndex: Int

    var body: some View {
        if let index = store.projects.firstIndex(where: { $0.id == projectID }),
           let script = store.projects[index].script,
           script.scenes.indices.contains(sceneIndex) {
            Form {
                Section("Narration") {
                    TextEditor(text: binding(index, \.narration)).frame(minHeight: 100)
                    Stepper("Duration: \(store.projects[index].script!.scenes[sceneIndex].duration, specifier: "%.1f")s", value: binding(index, \.duration), in: 1...20, step: 0.25)
                }
                Section("Camera") {
                    TextField("Latitude", value: cameraBinding(index, \.centerLatitude), format: .number)
                    TextField("Longitude", value: cameraBinding(index, \.centerLongitude), format: .number)
                    TextField("Altitude", value: cameraBinding(index, \.altitudeMeters), format: .number)
                    Slider(value: cameraBinding(index, \.headingDegrees), in: -20...20) { Text("Rotation") }
                    Slider(value: cameraBinding(index, \.pitchDegrees), in: 0...55) { Text("Pitch") }
                }
                Section("Visual instructions") {
                    ForEach(store.projects[index].script!.scenes[sceneIndex].overlays) { overlay in
                        VStack(alignment: .leading) {
                            Text(overlay.kind.rawValue.capitalized).bold()
                            Text(overlay.labels.joined(separator: ", ")).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .navigationTitle("Scene \(sceneIndex + 1)")
            .onDisappear { store.save() }
        }
    }

    private func binding<T>(_ projectIndex: Int, _ keyPath: WritableKeyPath<GeoScene, T>) -> Binding<T> {
        Binding(get: { store.projects[projectIndex].script!.scenes[sceneIndex][keyPath: keyPath] }, set: { store.projects[projectIndex].script!.scenes[sceneIndex][keyPath: keyPath] = $0 })
    }
    private func cameraBinding<T>(_ projectIndex: Int, _ keyPath: WritableKeyPath<CameraInstruction, T>) -> Binding<T> {
        Binding(get: { store.projects[projectIndex].script!.scenes[sceneIndex].camera[keyPath: keyPath] }, set: { store.projects[projectIndex].script!.scenes[sceneIndex].camera[keyPath: keyPath] = $0 })
    }
}
