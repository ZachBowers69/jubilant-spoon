import AVFoundation
import Foundation

@MainActor
final class SpeechTimeline: NSObject, ObservableObject, AVSpeechSynthesizerDelegate {
    @Published var spokenRange: NSRange = .init(location: 0, length: 0)
    @Published var isSpeaking = false
    let synthesizer = AVSpeechSynthesizer()

    override init() {
        super.init()
        synthesizer.delegate = self
    }

    func speak(_ text: String, settings: RenderSettings) {
        let utterance = AVSpeechUtterance(string: text)
        utterance.rate = settings.speakingRate
        utterance.pitchMultiplier = 1.0
        utterance.preUtteranceDelay = 0.15
        utterance.postUtteranceDelay = 0.2
        if let id = settings.voiceIdentifier { utterance.voice = AVSpeechSynthesisVoice(identifier: id) }
        synthesizer.speak(utterance)
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, willSpeakRangeOfSpeechString characterRange: NSRange, utterance: AVSpeechUtterance) {
        spokenRange = characterRange
        isSpeaking = true
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        isSpeaking = false
    }
}
