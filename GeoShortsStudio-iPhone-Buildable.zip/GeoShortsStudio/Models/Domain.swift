import Foundation
import CoreLocation

struct VideoIdea: Identifiable, Codable, Hashable {
    var id = UUID()
    var title: String
    var hook: String
    var angle: String
    var selected = false
}

struct GeoProject: Identifiable, Codable {
    var id = UUID()
    var name: String
    var createdAt = Date()
    var script: GeneratedScript?
    var renderSettings = RenderSettings()
}

struct GeneratedScript: Codable {
    var title: String
    var narration: String
    var scenes: [GeoScene]
}

struct GeoScene: Identifiable, Codable {
    var id = UUID()
    var narration: String
    var duration: Double
    var camera: CameraInstruction
    var overlays: [MapOverlayInstruction]
    var graphics: [GraphicInstruction]
    var soundEffects: [SoundEffectCue]
}

struct CameraInstruction: Codable {
    var centerLatitude: Double
    var centerLongitude: Double
    var altitudeMeters: Double
    var headingDegrees: Double = 0
    var pitchDegrees: Double = 0
    var easing: String = "easeInOut"
}

enum OverlayKind: String, Codable, CaseIterable {
    case country, admin1, city, continent, combinedRegions, route, arrow, expansion, overseasExpansion
}

struct MapOverlayInstruction: Identifiable, Codable {
    var id = UUID()
    var kind: OverlayKind
    var labels: [String]
    var geoJSONURL: String?
    var combineBorders: Bool = false
    var fillOpacity: Double = 0.20
    var lineWidth: Double = 4
    var animation: String = "draw"
}

struct GraphicInstruction: Identifiable, Codable {
    var id = UUID()
    var type: String
    var text: String?
    var assetName: String?
    var normalizedX: Double = 0.5
    var normalizedY: Double = 0.5
    var startTime: Double = 0
    var duration: Double = 1
}

struct SoundEffectCue: Identifiable, Codable {
    var id = UUID()
    var name: String
    var time: Double
    var volume: Double = 0.8
}

struct RenderSettings: Codable {
    var width = 1080
    var height = 1920
    var framesPerSecond = 30
    var captionStyle = "boldBottom"
    var voiceIdentifier: String?
    var speakingRate: Float = 0.48
}

enum ScriptProvider: String, CaseIterable, Identifiable {
    case manual = "Paste from ChatGPT"
    case openAI = "OpenAI API"
    case ollama = "Ollama"
    var id: String { rawValue }
}

enum TTSProvider: String, CaseIterable, Identifiable {
    case onDevice = "On-device Apple voice"
    case cloudflare = "Cloudflare Aura"
    var id: String { rawValue }
}
