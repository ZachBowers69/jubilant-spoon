export interface Env {
  AI: Ai;
  APP_TOKEN: string;
}

const speakers = new Set(["angus", "asteria", "arcas", "orion", "orpheus", "athena", "luna", "zeus", "perseus", "helios", "hera", "stella"]);

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    if (request.method === "GET") return Response.json({ ok: true, service: "GeoShorts TTS" });
    if (request.method !== "POST") return new Response("Method not allowed", { status: 405 });

    const auth = request.headers.get("Authorization");
    if (!env.APP_TOKEN || auth !== `Bearer ${env.APP_TOKEN}`) {
      return new Response("Unauthorized", { status: 401 });
    }

    let body: { text?: string; speaker?: string };
    try { body = await request.json(); }
    catch { return new Response("Invalid JSON", { status: 400 }); }

    const text = body.text?.trim() ?? "";
    if (!text || text.length > 5000) return new Response("Text must contain 1–5000 characters", { status: 400 });
    const speaker = speakers.has(body.speaker ?? "") ? body.speaker! : "luna";

    const audio = await env.AI.run("@cf/deepgram/aura-1", {
      text,
      speaker,
      encoding: "mp3"
    }, { returnRawResponse: true });

    return new Response(audio.body, {
      status: audio.status,
      headers: {
        "Content-Type": audio.headers.get("Content-Type") ?? "audio/mpeg",
        "Cache-Control": "no-store"
      }
    });
  }
} satisfies ExportedHandler<Env>;
